Pakiet Dokumentacja
===================

To archiwum zawiera komplet instrukcji:
- instalacja i pierwsze uruchomienie,
- instrukcja GUI,
- checklista bring-up,
- przewodnik HTML,
- karta operatora A4,
- zrzuty ekranow,
- opis paczek wdrozeniowych.