@echo off
setlocal
cd /d "%~dp0"
call "scripts\flash_mcu_safe_stlink.bat"
pause