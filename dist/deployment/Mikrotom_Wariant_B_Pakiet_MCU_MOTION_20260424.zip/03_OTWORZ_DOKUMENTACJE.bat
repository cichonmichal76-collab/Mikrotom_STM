@echo off
setlocal
cd /d "%~dp0"
call "scripts\open_variant_b_docs.bat"
pause