@echo off
setlocal
cd /d "%~dp0"
if exist "docs\START_HERE_Wariant_B.txt" start "" notepad.exe "docs\START_HERE_Wariant_B.txt"
if exist "docs\Wariant_B_Przewodnik_Kompletny.html" start "" "docs\Wariant_B_Przewodnik_Kompletny.html"
if exist "docs\Wariant_B_Instalacja_i_Pierwsze_Uruchomienie.md" start "" "docs\Wariant_B_Instalacja_i_Pierwsze_Uruchomienie.md"
if exist "docs\Wariant_B_Manual_Uzytkownika_GUI.md" start "" "docs\Wariant_B_Manual_Uzytkownika_GUI.md"
if exist "docs\STM32_Bringup_Checklist.md" start "" "docs\STM32_Bringup_Checklist.md"
if exist "docs\Pakiety_Wdrozeniowe_Wariant_B.md" start "" "docs\Pakiety_Wdrozeniowe_Wariant_B.md"
echo Otworzono dokumentacje.
pause