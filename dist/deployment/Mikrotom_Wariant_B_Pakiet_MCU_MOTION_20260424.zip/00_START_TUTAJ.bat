@echo off
setlocal
cd /d "%~dp0"
if exist "docs\START_HERE_Wariant_B.txt" start "" notepad.exe "docs\START_HERE_Wariant_B.txt"
if exist "docs\Wariant_B_Przewodnik_Kompletny.html" start "" "docs\Wariant_B_Przewodnik_Kompletny.html"
echo Otworzono przewodnik startowy.
pause