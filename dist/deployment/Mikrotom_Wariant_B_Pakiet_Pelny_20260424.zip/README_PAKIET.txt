Pakiet Pelny
============

To archiwum zawiera wszystko:
- GUI,
- Agenta,
- skrypty .bat,
- firmware SAFE,
- firmware MOTION-ENABLED,
- dokumentacje.

Zalecana kolejnosc:
1. 01_SPRAWDZ_WYMAGANIA.bat
2. 02_INSTALUJ_PC.bat
3. 03_WGRAJ_MCU_SAFE_STLINK.bat
4. 04_USTAW_GUI_LIVE.bat
5. 05_URUCHOM_AGENT.bat
6. 06_URUCHOM_GUI.bat
7. 08_WGRAJ_MCU_MOTION_STLINK.bat