@echo off
setlocal
cd /d "%~dp0"
call "scripts\flash_mcu_stlink.bat"
pause