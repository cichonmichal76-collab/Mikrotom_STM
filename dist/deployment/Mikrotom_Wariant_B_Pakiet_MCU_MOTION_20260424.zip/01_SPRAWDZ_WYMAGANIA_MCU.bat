@echo off
setlocal
cd /d "%~dp0"
call "scripts\check_variant_b_prerequisites.bat"
pause