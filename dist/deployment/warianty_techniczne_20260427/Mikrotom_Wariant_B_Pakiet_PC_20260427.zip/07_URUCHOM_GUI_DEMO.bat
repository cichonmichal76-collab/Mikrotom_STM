@echo off
setlocal
cd /d "%~dp0"
call "scripts\configure_gui_demo.bat"
call "scripts\run_gui.bat"