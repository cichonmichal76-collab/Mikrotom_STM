Pakiet MCU MOTION
=================

To archiwum sluzy do drugiego flashowania MCU, po pozytywnej walidacji SAFE.

Zawiera:
- firmware MOTION-ENABLED,
- skrypty flashowania,
- dokumentacje.

Ten wariant daje:
- HOME,
- MOVE_REL,
- MOVE_ABS,
- pierwszy kontrolowany ruch.

Nie zaczynaj od tej paczki.