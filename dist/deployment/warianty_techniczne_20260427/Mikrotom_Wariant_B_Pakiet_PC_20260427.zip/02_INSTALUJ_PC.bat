@echo off
setlocal
cd /d "%~dp0"
call "scripts\install_pc.bat"
pause