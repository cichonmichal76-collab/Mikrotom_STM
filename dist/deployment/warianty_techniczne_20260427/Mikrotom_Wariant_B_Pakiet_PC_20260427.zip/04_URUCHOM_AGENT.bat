@echo off
setlocal
cd /d "%~dp0"
call "scripts\run_agent_prompt.bat"