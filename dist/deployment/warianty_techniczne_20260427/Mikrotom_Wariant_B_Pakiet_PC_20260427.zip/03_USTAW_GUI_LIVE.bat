@echo off
setlocal
cd /d "%~dp0"
call "scripts\configure_gui_live.bat"
pause