@echo off
setlocal
cd /d "%~dp0"
call "scripts\flash_mcu_motion_stlink.bat"
pause