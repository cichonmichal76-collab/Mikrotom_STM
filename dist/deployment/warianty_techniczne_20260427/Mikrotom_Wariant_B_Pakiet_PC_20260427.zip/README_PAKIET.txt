Pakiet PC
=========

To archiwum jest przeznaczone na komputer podpiety do USB-UART.

Zawiera:
- GUI,
- Agenta,
- API,
- SQL,
- skrypty uruchomieniowe,
- dokumentacje.

Kolejnosc:
1. 01_SPRAWDZ_WYMAGANIA_PC.bat
2. 02_INSTALUJ_PC.bat
3. 03_USTAW_GUI_LIVE.bat
4. 04_URUCHOM_AGENT.bat
5. 05_URUCHOM_GUI.bat