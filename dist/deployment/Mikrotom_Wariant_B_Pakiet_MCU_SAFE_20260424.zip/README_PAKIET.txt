Pakiet MCU SAFE
===============

To archiwum sluzy do pierwszego flashowania MCU.

Zawiera:
- firmware SAFE,
- skrypty flashowania,
- dokumentacje.

Ten wariant daje:
- pelny feedback z urzadzenia,
- telemetrie,
- logi,
- komendy UART,
- brak realnego ruchu.